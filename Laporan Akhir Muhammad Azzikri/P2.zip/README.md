# Template Laporan Praktikum Jaringan Komputer

<img src="https://www.its.ac.id/komputer/wp-content/uploads/sites/28/2018/03/image10.png" alt="Teknik Komputer ITS" width="150" height="150">

## Deskripsi

Template ini dibuat untuk mempermudah praktikan membuat laporan dengan LaTex. Untuk poin-poin yang harus ada pada laporan sudah ditulis pada template.

## Panduan Instalasi

Untuk resource apa saja yang diperlukan dalam penggunaan template ini, dapat dilihat pada video youtube berikut :

[Instalasi kebutuhan penggunaan template LaTex](https://youtu.be/4lyHIQl4VM8?si=NKjpA3bkTzCn0Ruo)
